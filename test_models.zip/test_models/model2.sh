#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$HOME/eut+dats-stats-w26-GPU"
PROJECT_DIR="$HOME/eut+dats-stats-w26-GPU/v2tudembeded-model-GPU"
TEST_DIR="$PROJECT_DIR/test_models"

export LD_LIBRARY_PATH="$BASE_DIR/tools/llama.cpp/build/bin:${LD_LIBRARY_PATH:-}"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"

LLAMA_CLI="$BASE_DIR/tools/llama.cpp/build/bin/llama-completion"
MODEL="$BASE_DIR/models/mistral/Mistral-7B-Instruct-v0.3-Q4_K_M.gguf"
PROMPTS="$TEST_DIR/prompts.txt"

THREADS=28
TOKENS=300
GPU_LAYERS=999

OUT_TXT="$TEST_DIR/outputs_model2.txt"
TOK_FILE="$TEST_DIR/model2_total_output_tokens.txt"
AVG_TOK_FILE="$TEST_DIR/model2_avg_output_tokens.txt"

: > "$OUT_TXT"
echo 0 > "$TOK_FILE"
echo 0 > "$AVG_TOK_FILE"

total_tokens=0
query_count=0

while IFS= read -r prompt || [[ -n "$prompt" ]]; do
  [[ -z "$prompt" ]] && continue
  query_count=$((query_count + 1))

  formatted_prompt="Answer the following question.

Rules:
- Return only the final answer.
- Do not repeat the question.
- Do not explain your reasoning.
- For multiple-choice questions, return only one capital letter: A, B, C, or D.
- For numeric questions, return only the final number.
- For factual questions, return only a short factual answer.

Question:
$prompt

Answer:"

  output="$(
    "$LLAMA_CLI" \
      -m "$MODEL" \
      -p "$formatted_prompt" \
      -n "$TOKENS" \
      --temp 0 \
      -t "$THREADS" \
      -ngl "$GPU_LAYERS" \
      < /dev/null 2>/dev/null
  )"

  token_count="$(
    printf "%s" "$output" | python3 -c '
import re
import sys

text = sys.stdin.read().strip()
parts = re.findall(r"\w+|[^\w\s]", text, flags=re.UNICODE)
print(len(parts))
'
  )"

  total_tokens=$((total_tokens + token_count))

  {
    echo "[$query_count] PROMPT: $prompt"
    echo "[$query_count] OUTPUT TOKENS: $token_count"
    echo "[$query_count] OUTPUT:"
    echo "$output"
    echo
  } >> "$OUT_TXT"

done < "$PROMPTS"

if [[ "$query_count" -gt 0 ]]; then
  avg_tokens="$(
    python3 -c "
total_tokens = $total_tokens
query_count = $query_count
print(round(total_tokens / query_count, 4))
"
  )"
else
  avg_tokens="0"
fi

echo "$total_tokens" > "$TOK_FILE"
echo "$avg_tokens" > "$AVG_TOK_FILE"

echo "Model 2 run complete."
echo "Queries processed: $query_count"
echo "Total output tokens: $total_tokens"
echo "Average output tokens per query: $avg_tokens"
echo "Outputs saved to: $OUT_TXT"
