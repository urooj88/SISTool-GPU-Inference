#!/usr/bin/env python3
"""
collect_inference_metrics.py

Reads model scripts and gathers inference metrics WITHOUT rerunning models.
Uses saved outputs and token files from the main run.
Supports model1.sh, model2.sh, model3.sh, model4.sh

Accuracy is computed from:
- answers.csv

Outputs:
- model_inference_data.csv
- wrong_predictions_debug.csv
"""

import os
import re
import csv
import subprocess
from pathlib import Path
from typing import Optional, Dict, List, Tuple

CSV_OUT = "model_inference_data.csv"
DEBUG_WRONG_OUT = "wrong_predictions_debug.csv"
CARBON_INTENSITY = 300
SCRIPT_FILES = ["model1.sh", "model2.sh", "model3.sh", "model4.sh"]

PROMPTS_DEFAULT = "./prompts.txt"
ANSWERS_FILE = "answers.csv"

HERE = Path.cwd()


# ------------------------------------------------
# Read helper
# ------------------------------------------------
def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="replace")


# ------------------------------------------------
# Parse shell variables
# ------------------------------------------------
def parse_shell_vars(script_text: str) -> Dict[str, str]:
    vars_found: Dict[str, str] = {}

    for line in script_text.splitlines():
        line = line.strip()

        if not line or line.startswith("#"):
            continue

        m = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)=(.*)$', line)
        if not m:
            continue

        key = m.group(1)
        val = m.group(2).strip()

        if " #" in val:
            val = val.split(" #", 1)[0].strip()

        if (val.startswith('"') and val.endswith('"')) or (
            val.startswith("'") and val.endswith("'")
        ):
            val = val[1:-1]

        vars_found[key] = val

    return vars_found


# ------------------------------------------------
# Variable expansion
# ------------------------------------------------
def expand_with_vars(s: str, vars_dict: Dict[str, str]) -> str:
    if not s:
        return s

    expanded = s
    previous = None

    for _ in range(10):
        if expanded == previous:
            break

        previous = expanded
        expanded = os.path.expandvars(os.path.expanduser(expanded))

        for k, v in vars_dict.items():
            expanded = expanded.replace(f"${k}", v)
            expanded = expanded.replace(f"${{{k}}}", v)

    expanded = os.path.expandvars(os.path.expanduser(expanded))
    return expanded


# ------------------------------------------------
# Prompts
# ------------------------------------------------
def load_prompts(prompts_path: Path) -> List[str]:
    prompts: List[str] = []

    with prompts_path.open("r", encoding="utf-8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if line:
                prompts.append(line)

    return prompts


# ------------------------------------------------
# Model size
# ------------------------------------------------
def file_size_mb(p: Path) -> float:
    return round(p.stat().st_size / (1024 * 1024), 2)


# ------------------------------------------------
# Run command helper
# ------------------------------------------------
def run_cmd_capture(cmd: List[str]) -> str:
    proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
    return (proc.stdout or "") + "\n" + (proc.stderr or "")


# ------------------------------------------------
# Locate llama tools
# ------------------------------------------------
def find_binary_next_to(llama_cli_path: Path, binary_name: str) -> Optional[Path]:
    if not llama_cli_path.exists():
        return None

    candidate = llama_cli_path.parent / binary_name

    if candidate.exists() and os.access(candidate, os.X_OK):
        return candidate

    return None


# ------------------------------------------------
# Extract parameters
# ------------------------------------------------
def try_get_params_from_llama_gguf(
    llama_gguf: Path, model_path: Path
) -> Tuple[Optional[int], str]:
    attempts = [
        [str(llama_gguf), "info", str(model_path)],
        [str(llama_gguf), "--info", str(model_path)],
        [str(llama_gguf), "-i", str(model_path)],
        [str(llama_gguf), str(model_path)],
    ]

    out = ""
    worked = False

    for cmd in attempts:
        out = run_cmd_capture(cmd)

        if not out.strip():
            continue

        low = out.lower()

        if (
            "unknown option" in low
            or "unknown command" in low
            or "unrecognized option" in low
        ):
            continue

        worked = True
        break

    if not worked:
        return None, "no"

    patterns = [
        r"n_params\s*[:=]\s*([0-9]+)",
        r"general\.n_params\s*[:=]\s*([0-9]+)",
        r"model\.n_params\s*[:=]\s*([0-9]+)",
        r"parameters\s*[:=]\s*([0-9]+)",
    ]

    for pat in patterns:
        m = re.search(pat, out, flags=re.IGNORECASE)
        if m:
            return int(m.group(1)), "yes"

    return None, "no"


# ------------------------------------------------
# Fallback parameters from filename
# ------------------------------------------------
def params_from_filename_fallback(model_path: Path) -> Optional[int]:
    name = model_path.name.lower()

    m = re.search(r"-(\d+(?:\.\d+)?)\s*b-", name, flags=re.IGNORECASE)
    if not m:
        m = re.search(r"(\d+(?:\.\d+)?)\s*b", name, flags=re.IGNORECASE)

    if m:
        return int(float(m.group(1)) * 1_000_000_000)

    if "qwen2.5-7b" in name:
        return 7_000_000_000

    if "mistral-7b" in name:
        return 7_000_000_000

    if "llama-3.1-8b" in name or "meta-llama-3.1-8b" in name:
        return 8_000_000_000

    if "phi-3.5-mini" in name or "phi-3-mini" in name:
        return 3_800_000_000

    return None


# ------------------------------------------------
# FLOPs
# ------------------------------------------------
def compute_flops(params: int, tokens_generated: int) -> int:
    return int(2 * params * tokens_generated)


# ------------------------------------------------
# Parse outputs
# ------------------------------------------------
def parse_outputs_file(outputs_path: Path) -> Dict[int, str]:
    text = outputs_path.read_text(encoding="utf-8", errors="replace")

    pattern = re.compile(
        r"\[(\d+)\]\s+PROMPT:.*?\n"
        r"\[\1\]\s+OUTPUT TOKENS:.*?\n"
        r"\[\1\]\s+OUTPUT:\n"
        r"(.*?)(?=\n\[\d+\]\s+PROMPT:|\Z)",
        flags=re.DOTALL,
    )

    outputs_by_id: Dict[int, str] = {}

    for match in pattern.finditer(text):
        idx = int(match.group(1))
        out = match.group(2).strip()
        outputs_by_id[idx] = out

    return outputs_by_id


# ------------------------------------------------
# Answers.csv handling
# ------------------------------------------------
def answers_exists() -> bool:
    return (HERE / ANSWERS_FILE).exists()


def load_answers(path: Path) -> Dict[int, Dict[str, str]]:
    """
    answers.csv format:
    id,dataset,type,answer
    """
    answers: Dict[int, Dict[str, str]] = {}

    with path.open("r", encoding="utf-8", errors="replace", newline="") as f:
        r = csv.DictReader(f)

        required_cols = {"id", "type", "answer"}
        if not r.fieldnames or not required_cols.issubset(set(r.fieldnames)):
            raise RuntimeError("answers.csv must include at least: id,type,answer")

        for row in r:
            rid = int(str(row["id"]).strip())
            answers[rid] = {
                "dataset": str(row.get("dataset", "")).strip().lower(),
                "type": str(row["type"]).strip().lower(),
                "answer": str(row["answer"]).strip(),
            }

    return answers


# ------------------------------------------------
# Accuracy helpers
# ------------------------------------------------
def normalize_text(text: str) -> str:
    text = text.lower().strip()
    text = text.replace("\n", " ").replace("\r", " ")
    text = re.sub(r"\s+", " ", text)
    return text


def normalize_number_string(text: str) -> str:
    text = text.strip()
    text = text.replace(",", "")
    text = re.sub(r"^\$", "", text)
    text = re.sub(r"\s+", "", text)
    text = text.rstrip(".")
    return text


def clean_generation_artifacts(text: str) -> str:
    if not text:
        return ""

    cleaned = text
    cleaned = re.sub(r"llama_memory_breakdown_print:.*", "", cleaned, flags=re.DOTALL)
    cleaned = re.sub(r"\[\s*prompt:.*", "", cleaned, flags=re.IGNORECASE | re.DOTALL)
    cleaned = re.sub(r"exiting\.\.\..*", "", cleaned, flags=re.IGNORECASE | re.DOTALL)
    return cleaned.strip()


def normalize_reasoning_text(text: str) -> str:
    text = clean_generation_artifacts(text)
    text = text.replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def extract_last_number(text: str) -> str:
    """
    Flexible numeric extraction for GSM8K-style answers.
    """
    if not text:
        return ""

    cleaned = normalize_reasoning_text(text)
    low = cleaned.lower()

    patterns = [
        r"final\s+answer\s*[:=\-]?\s*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)",
        r"final\s+answer\s+is\s*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)",
        r"the\s+final\s+answer\s+is\s*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)",
        r"answer\s*[:=\-]?\s*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)",
        r"answer\s+is\s*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)",
        r"therefore[^0-9\-+]*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)",
        r"thus[^0-9\-+]*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)",
        r"so[^0-9\-+]*\$?\s*([-+]?\d[\d,]*(?:\.\d+)?)",
    ]

    for pat in patterns:
        matches = re.findall(pat, low, flags=re.IGNORECASE)
        if matches:
            return normalize_number_string(matches[-1])

    # try last non-empty line first
    lines = [line.strip() for line in cleaned.splitlines() if line.strip()]
    for line in reversed(lines):
        nums = re.findall(r"[-+]?\d[\d,]*(?:\.\d+)?", line)
        if nums:
            return normalize_number_string(nums[-1])

    # fallback: last number anywhere
    nums = re.findall(r"[-+]?\d[\d,]*(?:\.\d+)?", cleaned)
    if nums:
        return normalize_number_string(nums[-1])

    return ""


def extract_mcq_letter(text: str) -> str:
    if not text:
        return ""

    cleaned = clean_generation_artifacts(text).strip()

    patterns = [
        r"answer\s*[:=\-]?\s*([ABCD])\b",
        r"option\s*([ABCD])\b",
        r"choice\s*([ABCD])\b",
        r"^\s*([ABCD])\s*$",
        r"\b([ABCD])\b",
    ]

    for pat in patterns:
        m = re.search(pat, cleaned, flags=re.IGNORECASE | re.MULTILINE)
        if m:
            return m.group(1).upper()

    return ""


def remove_stopwords(words: set) -> set:
    stopwords = {
        "the", "a", "an", "is", "are", "was", "were", "be", "been", "being",
        "of", "to", "in", "on", "at", "for", "from", "with", "by", "as",
        "and", "or", "but", "if", "then", "than", "that", "this", "these",
        "those", "it", "its", "their", "there", "here", "into", "about",
        "after", "before", "during", "through", "over", "under", "between",
        "do", "does", "did", "not", "no", "yes", "can", "could", "should",
        "would", "may", "might", "must", "will", "shall", "have", "has",
        "had", "you", "your", "they", "them", "he", "she", "we", "i"
    }
    return {w for w in words if w not in stopwords}


def word_set(text: str) -> set:
    return set(re.findall(r"\b[a-z0-9]+\b", normalize_text(text)))


def score_reasoning(output_text: str, gold_answer: str) -> bool:
    pred = extract_last_number(output_text)
    gold = normalize_number_string(gold_answer)

    if not pred or not gold:
        return False

    try:
        return abs(float(pred) - float(gold)) < 1e-9
    except ValueError:
        return pred == gold


def score_mcq(output_text: str, gold_answer: str) -> bool:
    pred = extract_mcq_letter(output_text)
    gold = gold_answer.strip().upper()
    return bool(pred and gold and pred == gold)


def score_truth(output_text: str, gold_answer: str) -> bool:
    pred = normalize_text(clean_generation_artifacts(output_text))
    gold = normalize_text(gold_answer)

    if not pred or not gold:
        return False

    if gold in pred or pred in gold:
        return True

    pred_words = remove_stopwords(word_set(pred))
    gold_words = remove_stopwords(word_set(gold))

    if not pred_words or not gold_words:
        return False

    overlap = pred_words.intersection(gold_words)
    overlap_ratio = len(overlap) / max(len(gold_words), 1)

    return overlap_ratio >= 0.5


def score_output(output_text: str, answer_type: str, gold_answer: str) -> bool:
    answer_type = answer_type.strip().lower()

    if answer_type == "reasoning":
        return score_reasoning(output_text, gold_answer)

    if answer_type == "mcq":
        return score_mcq(output_text, gold_answer)

    if answer_type == "truth":
        return score_truth(output_text, gold_answer)

    pred = normalize_text(clean_generation_artifacts(output_text))
    gold = normalize_text(gold_answer)
    return bool(pred and gold and (gold in pred or pred in gold))


def compute_accuracy_from_saved_outputs(
    outputs_path: Path,
    answers_map: Dict[int, Dict[str, str]],
    model_name: str,
) -> Tuple[float, Dict[str, Dict[str, int]], Dict[str, Dict[str, int]], List[Dict[str, str]]]:
    outputs_by_id = parse_outputs_file(outputs_path)

    correct = 0
    total = 0

    type_stats = {
        "reasoning": {"correct": 0, "total": 0},
        "mcq": {"correct": 0, "total": 0},
        "truth": {"correct": 0, "total": 0},
    }

    dataset_stats: Dict[str, Dict[str, int]] = {}
    wrong_rows: List[Dict[str, str]] = []

    for rid, info in answers_map.items():
        if rid not in outputs_by_id:
            continue

        answer_type = info["type"]
        dataset_name = info.get("dataset", "")
        gold_answer = info["answer"]
        output_text = outputs_by_id[rid]

        is_correct = score_output(output_text, answer_type, gold_answer)

        total += 1
        if is_correct:
            correct += 1

        if answer_type in type_stats:
            type_stats[answer_type]["total"] += 1
            if is_correct:
                type_stats[answer_type]["correct"] += 1

        if dataset_name:
            if dataset_name not in dataset_stats:
                dataset_stats[dataset_name] = {"correct": 0, "total": 0}
            dataset_stats[dataset_name]["total"] += 1
            if is_correct:
                dataset_stats[dataset_name]["correct"] += 1

        if not is_correct:
            wrong_rows.append({
                "Model_Name": model_name,
                "id": str(rid),
                "dataset": dataset_name,
                "type": answer_type,
                "gold_answer": gold_answer,
                "model_output": output_text[:2500],
                "parsed_reasoning_number": extract_last_number(output_text) if answer_type == "reasoning" else "",
                "parsed_mcq_letter": extract_mcq_letter(output_text) if answer_type == "mcq" else "",
            })

    accuracy = round((correct / total) * 100, 2) if total > 0 else 0.0
    return accuracy, type_stats, dataset_stats, wrong_rows


# ------------------------------------------------
# Read token files
# ------------------------------------------------
def read_number_from_file(path: Path, cast_func=float, default=0):
    if not path.exists():
        return default

    content = path.read_text().strip()

    if not content:
        return default

    try:
        return cast_func(content)
    except Exception:
        return default


# ------------------------------------------------
# Collect per script
# ------------------------------------------------
def collect_from_script(script_path: Path) -> Tuple[Dict[str, object], List[Dict[str, str]]]:
    text = read_text(script_path)
    vars_ = parse_shell_vars(text)

    model_raw = vars_.get("MODEL", "").strip()
    prompts_raw = vars_.get("PROMPTS", "").strip() or PROMPTS_DEFAULT
    llama_cli_raw = vars_.get("LLAMA_CLI", "").strip()

    if not model_raw:
        raise RuntimeError(f"{script_path.name}: MODEL not found")

    if not llama_cli_raw:
        raise RuntimeError(f"{script_path.name}: LLAMA_CLI not found")

    model_path = Path(expand_with_vars(model_raw, vars_)).resolve()
    llama_cli_path = Path(expand_with_vars(llama_cli_raw, vars_)).resolve()

    prompts_expanded = expand_with_vars(prompts_raw, vars_)
    prompts_path = Path(prompts_expanded).resolve()

    if not model_path.exists():
        raise RuntimeError(f"{script_path.name}: model file not found: {model_path}")

    if not prompts_path.exists():
        raise RuntimeError(f"{script_path.name}: prompts file not found: {prompts_path}")

    if not llama_cli_path.exists():
        raise RuntimeError(f"{script_path.name}: llama executable not found: {llama_cli_path}")

    prompts = load_prompts(prompts_path)
    queries = len(prompts)
    model_size = file_size_mb(model_path)

    llama_gguf = find_binary_next_to(llama_cli_path, "llama-gguf")
    learned_params = None
    used_gguf = "no"

    if llama_gguf:
        learned_params, used_gguf = try_get_params_from_llama_gguf(llama_gguf, model_path)

    if learned_params is None:
        learned_params = params_from_filename_fallback(model_path)

    if learned_params is None:
        learned_params = 0

    stem = script_path.stem

    outputs_file = HERE / f"outputs_{stem}.txt"
    total_tok_file = HERE / f"{stem}_total_output_tokens.txt"
    avg_tok_file = HERE / f"{stem}_avg_output_tokens.txt"

    total_tokens = read_number_from_file(total_tok_file, int)
    avg_tokens = read_number_from_file(avg_tok_file, float)

    accuracy = 0.0
    type_stats = {
        "reasoning": {"correct": 0, "total": 0},
        "mcq": {"correct": 0, "total": 0},
        "truth": {"correct": 0, "total": 0},
    }
    dataset_stats: Dict[str, Dict[str, int]] = {}
    wrong_rows: List[Dict[str, str]] = []

    if answers_exists():
        answers_map = load_answers(HERE / ANSWERS_FILE)
        accuracy, type_stats, dataset_stats, wrong_rows = compute_accuracy_from_saved_outputs(
            outputs_file, answers_map, model_path.stem
        )

    flops = compute_flops(learned_params, int(round(avg_tokens))) if learned_params > 0 else 0

    reasoning_total = type_stats["reasoning"]["total"]
    mcq_total = type_stats["mcq"]["total"]
    truth_total = type_stats["truth"]["total"]

    reasoning_acc = (
        round((type_stats["reasoning"]["correct"] / reasoning_total) * 100, 2)
        if reasoning_total > 0 else 0.0
    )
    mcq_acc = (
        round((type_stats["mcq"]["correct"] / mcq_total) * 100, 2)
        if mcq_total > 0 else 0.0
    )
    truth_acc = (
        round((type_stats["truth"]["correct"] / truth_total) * 100, 2)
        if truth_total > 0 else 0.0
    )

    gsm8k_acc = 0.0
    mmlu_acc = 0.0
    truthfulqa_acc = 0.0

    if "gsm8k" in dataset_stats and dataset_stats["gsm8k"]["total"] > 0:
        gsm8k_acc = round(
            (dataset_stats["gsm8k"]["correct"] / dataset_stats["gsm8k"]["total"]) * 100, 2
        )

    if "mmlu" in dataset_stats and dataset_stats["mmlu"]["total"] > 0:
        mmlu_acc = round(
            (dataset_stats["mmlu"]["correct"] / dataset_stats["mmlu"]["total"]) * 100, 2
        )

    if "truthfulqa" in dataset_stats and dataset_stats["truthfulqa"]["total"] > 0:
        truthfulqa_acc = round(
            (dataset_stats["truthfulqa"]["correct"] / dataset_stats["truthfulqa"]["total"]) * 100, 2
        )

    row = {
        "Model_Name": model_path.stem,
        "queries": queries,
        "Model_Accuracy (%)": accuracy,
        "Reasoning_Accuracy (%)": reasoning_acc,
        "MCQ_Accuracy (%)": mcq_acc,
        "Truth_Accuracy (%)": truth_acc,
        "GSM8K_Accuracy (%)": gsm8k_acc,
        "MMLU_Accuracy (%)": mmlu_acc,
        "TruthfulQA_Accuracy (%)": truthfulqa_acc,
        "T_Model_Size (MB)": model_size,
        "Learned_Parameters": learned_params,
        "Flops_per_Inference": flops,
        "Carbon _Intensity (gCO₂/kWh)": CARBON_INTENSITY,
        "Used_llama_gguf": used_gguf,
        "Output_Tokens": total_tokens,
        "Avg_Output_Tokens_per_Query": avg_tokens,
    }

    return row, wrong_rows


# ------------------------------------------------
# Main
# ------------------------------------------------
def main():
    rows: List[Dict[str, object]] = []
    all_wrong_rows: List[Dict[str, str]] = []

    for sf in SCRIPT_FILES:
        sp = HERE / sf

        if not sp.exists():
            raise RuntimeError(f"Missing script: {sp}")

        row, wrong_rows = collect_from_script(sp)
        rows.append(row)
        all_wrong_rows.extend(wrong_rows)

    out_cols = [
        "Model_Name",
        "queries",
        "Model_Accuracy (%)",
        "Reasoning_Accuracy (%)",
        "MCQ_Accuracy (%)",
        "Truth_Accuracy (%)",
        "GSM8K_Accuracy (%)",
        "MMLU_Accuracy (%)",
        "TruthfulQA_Accuracy (%)",
        "T_Model_Size (MB)",
        "Learned_Parameters",
        "Flops_per_Inference",
        "Carbon _Intensity (gCO₂/kWh)",
        "Used_llama_gguf",
        "Output_Tokens",
        "Avg_Output_Tokens_per_Query",
    ]

    with open(CSV_OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=out_cols)
        w.writeheader()

        for r in rows:
            w.writerow({k: r.get(k, "") for k in out_cols})

    debug_cols = [
        "Model_Name",
        "id",
        "dataset",
        "type",
        "gold_answer",
        "model_output",
        "parsed_reasoning_number",
        "parsed_mcq_letter",
    ]
    with open(DEBUG_WRONG_OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=debug_cols)
        w.writeheader()
        for r in all_wrong_rows:
            w.writerow(r)

    print("Wrote:", CSV_OUT)
    print("Wrote:", DEBUG_WRONG_OUT)

    for r in rows:
        print("----")
        for k, v in r.items():
            print(f"{k}: {v}")

    if answers_exists():
        print("\nAccuracy note:")
        print("- answers.csv was found, so accuracy was computed from saved outputs.")
        print("- Per-type accuracy was computed for reasoning, mcq, and truth.")
        print("- Per-dataset accuracy was computed for gsm8k, mmlu, and truthfulqa when available.")
        print("- wrong_predictions_debug.csv was also written for manual checking.")
        print("- No second model run was performed.")
    else:
        print("\nAccuracy note:")
        print("- answers.csv not found, so Model_Accuracy (%) is reported as 0.0.")


if __name__ == "__main__":
    main()
