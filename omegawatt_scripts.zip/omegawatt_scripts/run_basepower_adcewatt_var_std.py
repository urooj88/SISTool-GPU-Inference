#!/usr/bin/env python3

import subprocess
import time
import pandas as pd
import os
import argparse
import signal
import sys


def run_wattmeter(output_dir, measurement_time=5):
    """Run the Adcewatt meter and save output to CSV."""
    meter_cmd = [
        "/home/urooj/Adcewatts-stool/wattmetre-readmv2new",
        "-t", "/dev/ttyUSB0"
    ]

    os.makedirs(output_dir, exist_ok=True)
    output_file = os.path.join(output_dir, "Adcewatt-output.csv")

    try:
        process = subprocess.Popen(
            meter_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )

        start_time = time.time()
        output_lines = []

        while time.time() - start_time < measurement_time:
            line = process.stdout.readline()
            if line:
                output_lines.append(line)

        process.terminate()
        try:
            process.wait(timeout=1)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()

        with open(output_file, "w") as f:
            f.writelines(output_lines)

        return True

    except Exception as e:
        print(f"Error running Adcewatt meter: {e}")
        return False


def process_power_data(csv_file):
    """Read meter CSV and calculate average power and energy."""
    try:
        df = pd.read_csv(csv_file)

        if "#activepow8" not in df.columns or "#activepow9" not in df.columns:
            raise ValueError("Required power columns '#activepow8' and '#activepow9' not found.")

        if "#timestamp" not in df.columns:
            raise ValueError("Required timestamp column '#timestamp' not found.")

        power8 = df["#activepow8"]
        power9 = df["#activepow9"]

        avg_power8 = power8.mean()
        avg_power9 = power9.mean()
        total_avg_power = avg_power8 + avg_power9

        measurement_duration_hours = (df["#timestamp"].max() - df["#timestamp"].min()) / 3600.0
        energy_consumption_wh = total_avg_power * measurement_duration_hours
        energy_consumption_joules = energy_consumption_wh * 3600.0

        print(f"Plug 8 average power: {avg_power8:.2f} W")
        print(f"Plug 9 average power: {avg_power9:.2f} W")

        return total_avg_power, energy_consumption_wh, energy_consumption_joules

    except Exception as e:
        print(f"Error processing CSV file: {e}")
        print("CSV contents:")
        try:
            with open(csv_file, "r") as f:
                print(f.read())
        except Exception as read_error:
            print(f"Could not read CSV file: {read_error}")
        return None, None, None


def main():
    parser = argparse.ArgumentParser(description="Monitor server baseline power consumption")
    parser.add_argument(
        "--repetitions",
        type=int,
        default=12,
        help="Number of measurement iterations"
    )
    parser.add_argument(
        "--sleep",
        type=int,
        default=0,
        help="Sleep time between iterations in seconds"
    )
    parser.add_argument(
        "--measurement-time",
        type=int,
        default=5,
        help="Measurement duration per iteration in seconds"
    )

    args = parser.parse_args()

    output_dir = "."
    results_file = os.path.join(output_dir, "power_out.txt")
    csv_file = os.path.join(output_dir, "Adcewatt-output.csv")

    # Remove old result file if it exists
    if os.path.exists(results_file):
        os.remove(results_file)

    total_power = 0.0
    total_energy_wh = 0.0
    total_energy_joules = 0.0
    successful_runs = 0

    def signal_handler(sig, frame):
        print("\nCaught Ctrl+C, exiting safely...")
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    print(f"Starting baseline power monitoring for {args.repetitions} iterations...")

    for i in range(args.repetitions):
        print(f"\nIteration {i + 1}/{args.repetitions}")

        ok = run_wattmeter(output_dir, args.measurement_time)
        if ok:
            avg_power, energy_wh, energy_joules = process_power_data(csv_file)

            if avg_power is not None:
                total_power += avg_power
                total_energy_wh += energy_wh
                total_energy_joules += energy_joules
                successful_runs += 1

                print(f"Total average power: {avg_power:.2f} W")
                print(f"Energy consumption: {energy_wh:.2f} Wh ({energy_joules:.2f} J)")

        if i < args.repetitions - 1:
            print(f"Sleeping for {args.sleep} seconds...")
            time.sleep(args.sleep)

    if successful_runs > 0:
        final_avg_power = total_power / successful_runs
        total_time_seconds = args.repetitions * args.measurement_time
        total_energy_from_power = final_avg_power * total_time_seconds

        with open(results_file, "w") as f:
            f.write(f"Average Power Consumption: {final_avg_power:.2f} W\n")
            f.write(f"Total Time: {total_time_seconds} seconds\n")
            f.write(f"Total Energy (from avg power): {total_energy_from_power:.2f} Joules\n")

        print("\nFinal Results:")
        print(f"Baseline/Average Power Consumption (both): {final_avg_power:.2f} W")
        print(f"Total Time: {total_time_seconds} seconds")
        print(f"Baseline Total Energy (from avg power): {total_energy_from_power:.2f} Joules")
        print(f"Results saved to: {results_file}")
    else:
        print("No successful measurements were recorded.")


if __name__ == "__main__":
    main()
