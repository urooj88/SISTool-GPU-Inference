#!/usr/bin/env python3

import subprocess
import time
import pandas as pd
import os
import argparse
import threading
import psutil
import csv

# ----------------------------
# Directories
# ----------------------------
THIS_DIR = os.path.dirname(os.path.abspath(__file__))   # .../omegawatt_scripts
BASE_DIR = os.path.dirname(THIS_DIR)                    # project root
TEST_MODELS_DIR = os.path.join(BASE_DIR, "test_models")

LOGS_DIR = os.path.join(BASE_DIR, "model_logs")
os.makedirs(LOGS_DIR, exist_ok=True)

# ----------------------------
# File paths
# ----------------------------
baseline_file = os.path.join(LOGS_DIR, "baseline_value.txt")
power_log = os.path.join(LOGS_DIR, "mxm_power.csv")
power_out_txt = os.path.join(LOGS_DIR, "power_out.txt")

model1_log = os.path.join(LOGS_DIR, "model1_samples.csv")
model2_log = os.path.join(LOGS_DIR, "model2_samples.csv")
model3_log = os.path.join(LOGS_DIR, "model3_samples.csv")
model4_log = os.path.join(LOGS_DIR, "model4_samples.csv")

# Main metrics CSV stays in project root
metrics_path = os.path.join(BASE_DIR, "model_metrices.csv")

# Baseline script path
BASELINE_SCRIPT = os.path.join(THIS_DIR, "run_basepower_adcewatt_var_std.py")

# ----------------------------
# Same-run output/token files in test_models
# ----------------------------
outputs_model1 = os.path.join(TEST_MODELS_DIR, "outputs_model1.txt")
outputs_model2 = os.path.join(TEST_MODELS_DIR, "outputs_model2.txt")
outputs_model3 = os.path.join(TEST_MODELS_DIR, "outputs_model3.txt")
outputs_model4 = os.path.join(TEST_MODELS_DIR, "outputs_model4.txt")

tokens_model1 = os.path.join(TEST_MODELS_DIR, "model1_total_output_tokens.txt")
tokens_model2 = os.path.join(TEST_MODELS_DIR, "model2_total_output_tokens.txt")
tokens_model3 = os.path.join(TEST_MODELS_DIR, "model3_total_output_tokens.txt")
tokens_model4 = os.path.join(TEST_MODELS_DIR, "model4_total_output_tokens.txt")

avg_tokens_model1 = os.path.join(TEST_MODELS_DIR, "model1_avg_output_tokens.txt")
avg_tokens_model2 = os.path.join(TEST_MODELS_DIR, "model2_avg_output_tokens.txt")
avg_tokens_model3 = os.path.join(TEST_MODELS_DIR, "model3_avg_output_tokens.txt")
avg_tokens_model4 = os.path.join(TEST_MODELS_DIR, "model4_avg_output_tokens.txt")


# ---------------------------------------------------
# Cleanup
# ---------------------------------------------------
def clean_old_files():
    files = [
        baseline_file,
        power_log,
        power_out_txt,
        model1_log,
        model2_log,
        model3_log,
        model4_log,
        metrics_path,

        # same-run outputs/tokens
        outputs_model1,
        outputs_model2,
        outputs_model3,
        outputs_model4,
        tokens_model1,
        tokens_model2,
        tokens_model3,
        tokens_model4,
        avg_tokens_model1,
        avg_tokens_model2,
        avg_tokens_model3,
        avg_tokens_model4,
    ]

    for f in files:
        if os.path.exists(f):
            os.remove(f)
            print(f"[CLEANUP] Removed: {f}")


# ---------------------------------------------------
# Baseline measurement
# ---------------------------------------------------
def measure_baseline_once():
    if os.path.exists(baseline_file):
        with open(baseline_file, "r") as f:
            baseline = float(f.read().strip())
        print(f"[BASELINE] Loaded existing baseline: {baseline:.2f} W")
        return baseline

    if not os.path.exists(BASELINE_SCRIPT):
        raise FileNotFoundError(f"Baseline script not found: {BASELINE_SCRIPT}")

    print("[BASELINE] Measuring baseline power...")

    cmd = [
        "python3",
        BASELINE_SCRIPT,
        "--repetitions", "12",
        "--measurement-time", "5",
        "--sleep", "0",
    ]

    # Run baseline inside LOGS_DIR so output files are created there
    subprocess.run(cmd, cwd=LOGS_DIR, check=True)

    if not os.path.exists(power_out_txt):
        raise RuntimeError(f"Baseline failed: missing {power_out_txt}")

    baseline_power = None
    with open(power_out_txt, "r") as f:
        for line in f:
            if "Average Power Consumption" in line:
                baseline_power = float(line.split()[3])
                break

    if baseline_power is None:
        raise RuntimeError("Could not parse baseline power from power_out.txt")

    with open(baseline_file, "w") as f:
        f.write(str(baseline_power))

    print(f"[BASELINE] Measured baseline: {baseline_power:.2f} W")
    return baseline_power


# ---------------------------------------------------
# Resource monitor
# ---------------------------------------------------
def monitor_model_resource(pid, sample_log_file, stop_event, results_dict, gpu_count=1):
    proc = psutil.Process(pid)
    start = time.time()

    cpu_samples = []
    mem_samples = []

    with open(sample_log_file, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Time_s", "CPU_Use_%", "Mem_GiB"])

        while not stop_event.is_set():
            try:
                timestamp = time.time() - start
                cpu = proc.cpu_percent(interval=0.1)
                mem = proc.memory_info().rss

                for child in proc.children(recursive=True):
                    try:
                        cpu += child.cpu_percent(interval=0.1)
                        mem += child.memory_info().rss
                    except psutil.NoSuchProcess:
                        pass

                mem = mem / (1024 ** 3)

                cpu_samples.append(cpu)
                mem_samples.append(mem)

                writer.writerow([round(timestamp, 2), round(cpu, 2), round(mem, 3)])
                time.sleep(1.9)

            except psutil.NoSuchProcess:
                break

    elapsed = time.time() - start
    avg_cpu = sum(cpu_samples) / len(cpu_samples) if cpu_samples else 0.0
    max_mem = max(mem_samples) if mem_samples else 0.0
    cpu_hrs = (avg_cpu / 100.0) * elapsed / 3600.0
    gpu_hrs = gpu_count * elapsed / 3600.0

    results_dict.update({
        "Execution_Time_s": round(elapsed, 2),
        "CPU_Use_%": round(avg_cpu, 2),
        "Max_Mem_GiB": round(max_mem, 3),
        "CPU_Core_Hours": round(cpu_hrs, 6),
        "GPU_Count": int(gpu_count),
        "GPU_Hours": round(gpu_hrs, 6),
    })


# ---------------------------------------------------
# Power + model measurement
# ---------------------------------------------------
def measure_power_for_model(model_name, script_path, baseline_power, gpu_count=1):
    print(f"\nRunning {model_name} ({script_path})")

    if not os.path.exists(script_path):
        raise FileNotFoundError(f"Missing model script: {script_path}")

    prompts_path = os.path.join(TEST_MODELS_DIR, "prompts.txt")
    if not os.path.exists(prompts_path):
        raise FileNotFoundError(f"Missing prompts.txt: {prompts_path}")

    # Start wattmeter logging
    meter_out = open(power_log, "w")
    meter = subprocess.Popen(
        [
            "/home/urooj/Adcewatts-stool/wattmetre-readmv2new",
            "-t",
            "/dev/ttyUSB0",
        ],
        stdout=meter_out,
        stderr=subprocess.PIPE,
        cwd=LOGS_DIR,
    )

    time.sleep(1)

    # Run model from TEST_MODELS_DIR so prompts/output files are written there
    process = subprocess.Popen(
        ["bash", script_path],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        cwd=TEST_MODELS_DIR,
    )

    start_time = time.time()

    if model_name == "Model1":
        sample_log = model1_log
    elif model_name == "Model2":
        sample_log = model2_log
    elif model_name == "Model3":
        sample_log = model3_log
    else:
        sample_log = model4_log

    stop_event = threading.Event()
    monitor_results = {"Model_Name": model_name}

    monitor_thread = threading.Thread(
        target=monitor_model_resource,
        args=(process.pid, sample_log, stop_event, monitor_results, gpu_count),
    )
    monitor_thread.start()

    stdout, stderr = process.communicate()
    exec_time = time.time() - start_time

    stop_event.set()
    monitor_thread.join()

    # Stop meter
    meter.terminate()
    try:
        meter.wait(timeout=2)
    except subprocess.TimeoutExpired:
        meter.kill()

    meter_out.close()

    if process.returncode != 0:
        out = stdout.decode(errors="replace").strip()
        err = stderr.decode(errors="replace").strip()
        print("[MODEL STDOUT]\n", out)
        print("[MODEL STDERR]\n", err)
        raise RuntimeError(f"{model_name} failed (exit {process.returncode}).")

    if not os.path.exists(power_log):
        raise RuntimeError(f"Power log missing: {power_log}")

    df = pd.read_csv(power_log)

    if "#activepow8" not in df.columns or "#activepow9" not in df.columns:
        raise RuntimeError("Power log does not contain required columns: #activepow8 and #activepow9")

    total_power = df["#activepow8"] + df["#activepow9"]
    avg_power = total_power.mean()

    dynamic_power = avg_power - baseline_power
    total_energy = avg_power * exec_time
    dynamic_energy = dynamic_power * exec_time

    return {
        "Model_Name": model_name,
        "Baseline_Power_W": round(baseline_power, 2),
        "Total_Power_W": round(avg_power, 2),
        "Dynamic_Power_W": round(dynamic_power, 2),
        "Total_Execution_Time_s": round(exec_time, 3),
        "Total_Energy_J": round(total_energy, 2),
        "Dynamic_Energy_J": round(dynamic_energy, 2),
        **monitor_results,
    }


# ---------------------------------------------------
# Update metrics CSV
# ---------------------------------------------------
def update_metrics_csv(row):
    if os.path.exists(metrics_path):
        df = pd.read_csv(metrics_path)
    else:
        df = pd.DataFrame(columns=row.keys())

    if "Model_Name" in df.columns and row["Model_Name"] in df["Model_Name"].values:
        for key, value in row.items():
            df.loc[df["Model_Name"] == row["Model_Name"], key] = value
    else:
        df = pd.concat([df, pd.DataFrame([row])], ignore_index=True)

    df.to_csv(metrics_path, index=False)
    print(f"[CSV] Updated: {metrics_path}")


# ---------------------------------------------------
# Main
# ---------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--app-type",
        choices=["serial", "parallel", "third", "fourth"],
        required=True
    )
    parser.add_argument(
        "--gpu-count",
        type=int,
        default=1,
        help="Number of GPUs used by the model run"
    )
    args = parser.parse_args()

    if args.gpu_count <= 0:
        raise ValueError("--gpu-count must be greater than 0")

    # Clean only once before the first model
    if args.app_type == "serial":
        clean_old_files()

    baseline_power = measure_baseline_once()

    if args.app_type == "serial":
        model_name = "Model1"
        script_path = os.path.join(TEST_MODELS_DIR, "model1.sh")
    elif args.app_type == "parallel":
        model_name = "Model2"
        script_path = os.path.join(TEST_MODELS_DIR, "model2.sh")
    elif args.app_type == "third":
        model_name = "Model3"
        script_path = os.path.join(TEST_MODELS_DIR, "model3.sh")
    else:
        model_name = "Model4"
        script_path = os.path.join(TEST_MODELS_DIR, "model4.sh")

    result = measure_power_for_model(
        model_name=model_name,
        script_path=script_path,
        baseline_power=baseline_power,
        gpu_count=args.gpu_count,
    )
    update_metrics_csv(result)

    print(f"\nCompleted: {model_name}")
    print(f"Logs saved in: {LOGS_DIR}")
    print(f"Metrics saved in: {metrics_path}")


if __name__ == "__main__":
    main()
